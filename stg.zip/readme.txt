STG (SNMP Traffic Grapher) version 1.4.5
Copyright (C) 2000 Leonid Mikhailov


This freeware utility allows monitoring of supporting 
SNMPv1 and SNMPv2c devices including Cisco, Livingstone,
Riverstone etc.

Intended as fast aid for network administrators who 
need prompt access to current information about state of
network equipment.


Copyright 
 
  In brief:
  You may use STG for any commercial and non commercial purpose.
  You may distribute STG for free.
  You may charge a fee for the physical act of transferring a copy only.
  This program is distributed WITHOUT ANY WARRANTY. 
  Use it at your own risk.
  I cannot guarantee accuracy of displayed data.
  I am not liable to you for any possible damages etc...


Source code is not available.


Features: 

  Single graph displays changes of two configurable 
  SNMP variables with display of Current, Average, Maximum values.
  Screen snapshot: http://www.chat.ru/~leonidvm/stg.jpg

Could be downloaded from: 
   http://www.chat.ru/~leonidvm/
   ftp://ftp.naytov.com/pub/stg/

Newer versions will be there too.

STG was written as an add-on for MRTG application by Tobias Oetiker.
MRTG (http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html)
is absolutely necessary for every network and system administrator.
It provides SNMP monitoring of any number devices simultaneously.

However during my duties I often have to check state
of ports on different routers that are not always in my
domain and setting MRTG configuration takes some time.
And does not allow to see last second changes in traffic.

That's why STG was written.
It allows monitoring of SNMP devices with different update periods
starting from  0.01s so you could see what's happening right now. 

Also STG could be useful during network problems troubleshooting.

 
It runs on MS Windows 2000, Windows NT 4.0, Windows 98 and Windows Millenium. 
To run it on WinNT 4.0 you may need  mgmtapi.dll and mib.bin (see below)
To run it on Win98 and Millenium you will need  mgmtapi.dll, mib.bin and 
wsnmp32.dll (see below)

Written with Microsoft Visual C++ 6.0.
Uses Microsoft SNMP API.

Features: Single graph displays changes of two configurable 
SNMP variables with display of Current, Average, Maximum values.

Changes in version 1.4.5:
  Bugs fixed:
      1. Corrected bug that prevented version 1.4.4 from running on NT4

Changes in version 1.4.4:
  Bugs fixed:
      1. Fixed bug with log file where sysUpTime was shown as nonzero 
         for timeouted requests

Changes in version 1.4.3:
  Bugs fixed:
      1. Fixed bug with average value displayed incorrectly. 
    - Thanks to Jim Jones, Jr.!
      2. Fixed bug when red Upper Rate line has incorrect position for high Max Rate 
         numbers. 

Changes in version 1.4.2:
      Now runs on Win 98 and Millenium.
  Bugs fixed:
      1. Corrected startup crash (when started with configuration filename)
    - Thanks to Paw Larsen!

Changes in version 1.4.1:
      1. Both snmp OID's are requested in one network packet.
      2. Actual time between two requests is calculated from 
         target device sysUpTime (1.3.6.1.2.1.1.3.0).
      This should improve displayed data accuracy.
    - Thanks to Mike MacFaden from Riverstone Networks!
      3. Log format changed:
           request_time,target_uptime_centisec,traffic,traffic1
              request_time  - local system time (human readable string)
              target_uptime - target sysUpTime (hundredth of seconds)
              traffic
              traffic1
         e.g.: 
           2001-Feb-12 15:07:28.89,24244074,5078,21215
  Features added:
      1. Window size and status/title bar state are being saved/restored.

Changes in version 1.4.0:
  Bugs fixed:
      1. One memory leak fixed.
  Features added:
      1. Resizeable window.
     
Changes in version 1.3.2:
  Bugs fixed:
      1. Corrected bug with zero replies not included in Avg value.
         Thanks to Rafael Prado Rocchi!

Changes in version 1.3.1:
  Features added:
      1. Option for displaying traffic in bits/bytes
      2. Target Information window.

Changes in version 1.2.2:
  Bugs fixed:
      1. Corrected bug with time incorrectly shown when daylight saving 
         option was on. Thanks to Anders Gustafsson from Sweden!
      2. Changed the way of rate calculation. Now rate is calculated on
         basis of time that actually passed since previous sample.
         Before the value of "Update Period" option was used.

  Features added:
      1. Status bar indicator of last sample time.
      2. Logging ability. If option "Write Data to Log File" is checked,
         then program writes collected data to specified file.
         Log file is comma separated. Here is format:
           First line is the header line :
             Program name: File creation time,Target Address,Community string,OID,OID1
                   e.g.:
STG Traffic Log File Created On:Sat Jun 03 14:18:36 2000,Target Address:195.239.193.125,Community:public,OID:1.3.6.1.2.1.2.2.1.10.1,OID1:1.3.6.1.2.1.2.2.1.16.1

           Second line lists values names.
           From third line starts actual program data.
      3. Log file is rotated every N hours, days, weeks or months.
         Rotation happens at the end of hour, day, week or month respectively.  



Configuration Options:

  Graph:
    SNMP values:
      Target Address:
        e.g 
  	     myrouter1.mydomain.com
      Community:
        e.g 
  	     public
      Two SNMP Object IDs (SNMP ID of the parameter you want to see): 
        OID   
  	    e.g
  	     1.3.6.1.2.1.2.2.1.10.1
        OID1
  	    e.g 
  	     1.3.6.1.2.1.2.2.1.16.1
          Every or any of them could be gauge value - some SNMP parameters
             should be treated as absolute ("as is") (e.g CPU load or temperature)
          In case you need only one walue - enter the same string
             into both OID and OID1 fields.
          If you need more than two - try to use more than one 
  	         instance of program.
  	  
    Network values:
      Request Timeout (milliseconds):
           minimal 10ms (0.01 sec)
           maximal 32000ms (32s) 
               probably shouldn't be more than 5000 (5 seconds)
                  but that's vary
      Update Period (milliseconds):
           minimal 100ms (0.1 sec)
           maximal 2000000000ms (Too long to wait...) 
               To get valid graph this value should be set 
                  higher than network timeout.
      Max Rate - byte/second:
           minimal 1 
           maximal  2000000000
               This option determines position of horisontal red line.
               Note, it is in bytes in second, so if you want
                  to monitor 1Mbit line it should be set a little 
                  higher than 131072
                
      Reverse option - changes direction of graph.  

      Show traffic in Bytes / Bits - show traffic values in bits or bytes

      Fix Rate - Show graph data only up to "Max Rate" and don't allow 
                 automatic scaling.

  Log File:
      Write Data - enables/disables logging.
      To Log File -  specifies file for logging.
      Rotate N Log Files - specifies number of log files to rotate  
           - minimum 1. Rotated files will have numeric extention added:
             *.000 
             *.001      
             etc.
      Every N Hour(s) or Day(s) or Week(s) or Month(s)  - rotate log period.
      Rotation happens at the end of hour, day, week or month respectively.  
      
      Log file format:
           request_time,target_uptime_centisec,traffic,traffic1
              request_time  - local system time (human readable string),
              target_uptime - target sysUpTime (hundredth of seconds),
              traffic       - 
              traffic1      -
         e.g.: 
           2001-Feb-12 15:07:28.89,24244074,5078,21215

   
  Settings could be saved and recalled through Save and Open menus.
  Program uses ".stg" extention for settings files.


Files in installation:
           ftp://ftp.naytov.com/pub/stg/1.4.5/stg.zip
  stg.exe     - program
  readme.txt  - this file
  mibs.txt    - examples of some SNMP Object IDs to monitor. 

Additional files (required only for running on WinNT 4.0):
            ftp://ftp.naytov.com/pub/stg/winnt4.0/nt4files.zip
  mgmtapi.dll - Microsoft SNMP API runtime library 
  mib.bin     - File necessary for parsing OIDs 

Additional files (required only for running on WinNT 98 and Millenium):
            ftp://ftp.naytov.com/pub/stg/w9x/w9xlibs.zip
  mgmtapi.dll - Microsoft SNMP API runtime library 
  mib.bin     - File necessary for parsing OIDs 
  wsnmp32.dll - WinSNMP Library 

Installation How2:

  Win2000:
    1. Download stg.zip (128k)
      http://www.chat.ru/~leonidvm/1.4.5/stg.zip
      ftp://ftp.naytov.com/pub/stg/1.4.5/stg.zip

    2. Extract stg.exe with pkunzip or winzip into any directory
       (e.g. "\Program Files\STG")

  Winnt 4.0:
    1. Download stg.zip 
    2. Get mgmtapi.dll and mib.bin if they are not already 
          in \WINNT\system32\ directory.
       You could find them in your WinNT installation CD-ROM in i386 
          directory 
       Or download nt4files.zip (11.5k) from 
 
           http://www.chat.ru/~leonidvm/nt4files.zip 
         or
           ftp://ftp.naytov.com/pub/stg/winnt4.0/nt4files.zip

    3. Extract all files from stg.zip with pkunzip or winzip into installation
       directory  (e.g. "\Program Files\STG") 
    4. Extract mgmtapi.dll and mib.bin from nt4files.zip into the same 
       directory as stg.exe (or into \WINNT\system32\).

  Winnt 98 and Millenium:
    1. Download stg.zip 
    2. Get mgmtapi.dll, mib.bin and wsnmp32.dll
        - download w9xlibs.zip (39k) from 
 
           http://www.chat.ru/~leonidvm/w9xlibs.zip
         or
           ftp://ftp.naytov.com/pub/stg/w9x/w9xlibs.zip

    3. Extract all files from stg.zip with pkunzip or winzip into installation
       directory  (e.g. "\Program Files\STG") 
    4. Extract mgmtapi.dl, mib.bin and wsnmp32.dll from w9xlibs.zip into 
       the same directory as stg.exe (or into \windows\).


Deinstallation: 

    1. Remove all files from STG directory.
    2. Remove STG directory.


Running STG

Prerequisites:
   1. Valid DNS name or IP address of device you want to monitor.
   2. Valid SNMP OID (for some values see mibs.txt file)
   3. Correct SNMP community (might be "public", but not necessary).
   4. SNMP should be configured on target device. 
   5. Your computer must have access to SNMP facility
      (be in access list or something like that -  ask sysadmin).

Configuration:
   1. Open menu View\Settings
   2. Set DNS name or ip address of monitoring device into 
      Target Adress edit box.
   3. Set correct community string into Community edit box.
   4. Set OID of the first object in OID edit box.
   5. Set OID of second object in OID1 edit box. 
   6. Set Update Period to desired value in milliseconds.
   7. Set Max Rate to desired Value (This parameters is in bytes!).
   8. Press OK.
 Monitoring starts automatically.



Problems and Troubleshooting:

  If program cannot resolve Target Address or process OIDs,
    it reports error and stops processing.
    To resume it you may correct mistakes and it will retry
    automatically. 
    Or you may use menu command Start to restart monitoring.

Errors in OID:
  If you are sure that OID string is correct - than you need to check
     that mib.bin is in the STG directory 
        or in \WINNT\system32\ if you run WinNT4.0 
        or \windows\  if you run Win98 or Millenium.

Entry Point Not Found:
  This error arises in Win2000 when mgmtapi.dll from WinNT4.0 is somewhere 
     in your path. Find mgmtapi.dll and delete it.

Vertical Red Line:
  Vertical red line on graph means that there were no
     valid data received from target address within Request 
  Timeout period.
  There may be different reasons for that:
    1. Network Timeout - try to increase Request Timeout
         value (there is no reason for setting it higher 10000ms -
	 it would not help) 
	 This implemetation uses SNMP protocol with 
	 no retries (could be changed in future).
	 And SNMP uses UDP protocol with no deluvery guaranties.
	 So this could happen.
    2. Overloaded network connection between monitoring computer
         and target. 
    3. Mistyped Target Address or OIDs.
         If you get olny solid red than checking them might 
         be useful.

Share violation occured while accessing ....
  This message appears when two or more instances of stg try to write
     into the same log file. Make log file name unique for every instance.


If you have found a bug or have suggestions - send me a message to 
   leonidvm@mail.com

I will try to correct a problem.
But no guarantees.

Hope this utility will be useful for you.




Author: Leonid Mikhailov
Tashkent, Uzbekistan

email: leonidvm@mail.com


Links:
  For the list of SNMP software have a look:
     http://wwwsnmp.cs.utwente.nl/software/pubdomain.html
  SNMP FAQ:
     http://www.faqs.org/faqs/snmp-faq/part1/
  SNMP RFCs:
     http://www.cis.ohio-state.edu/htbin/rfc/rfc1157.html
     http://www.cis.ohio-state.edu/htbin/rfc/rfc1901.html
  Network Management Operations tools
  from Riverstone Networks
     http://www.nmops.org
